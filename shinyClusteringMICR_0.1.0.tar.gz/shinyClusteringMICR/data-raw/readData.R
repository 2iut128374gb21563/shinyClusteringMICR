readGeneAnnot <- function(){
  array_annotation <- read.csv(file = system.file("extdata", "rgdAnnot.txt", package = "shinyClusteringMICR"),
                         header = TRUE,
                         sep = "\t")
  save(array_annotation, file = "data/array_annotation.RData", compress = "xz")
}
readArrayData <- function(){
  array_data <- read.csv(file = system.file("extdata", "cllnormalized.txt", package = "shinyClusteringMICR"),
                       header = TRUE,
                       sep = "\t")
  save(array_data, file = "data/array_data.RData", compress = "xz")
}
