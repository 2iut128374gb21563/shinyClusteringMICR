#library(ggplot2)
#library(reshape2)
#library(dplyr)
#library(dendextend)

#' Generiert Datenobjekt aus Rohdaten
#'
#' Array-Daten und Array-Annotation werden aus den binaer abgelegten ".RData" Dateien
#' (Code zur Generierung der Binaerdaten s. Verzeichnis "data-raw/") geladen.
#' Zeilen mit unbenutzten ("blank") Spots werden aus den Array-Daten entfernt
#' und die Matrix wird in die fuer die weiteren Funktionen benoetigten Gestalten
#' transformiert.
#'
#' @return Ein Objekt vom Typ \code{list} mit den Elementen:
#' * \code{data_transp}: Objekt vom Typ \code{matrix} mit 12 Zeilen (Patient/Sample) und 32112 Spalten (Gen/spot)
#' * \code{data_melted}: Objekt vom Typ \code{data.frame} mit 385344 Zeilen und 4 Spalten:
#'   * Spot: Laufende Spotnummer auf dem Array
#'   * Patient: ID des Samples/Patienten
#'   * Intensity: Normalisierter Intensitaetswert des Spots
#'   * Group: Gruppierungsvariable; gibt an, ob der Patient zur Gruppe "CLL" oder "NBC" gehoert.
#' * \code{data_blankless}: Objekt vom Typ \code{data.frame} mit 32112 Zeilen (Gen/Spot)
#' und 13 Spalten (1: Laufende Spotnummer, 2-13: Patient/Sample)
#' * \code{gene_annot}: Objekt vom Typ \code{data.frame} mit 34560 Zeilen und 9 Spalten:
#'   * ID: Laufende Spotnummer
#'   * acc: GenBank accession number
#'   * UniGene: UniGene accession number
#'   * Symbol: GeneSymbol
#'   * Description: Beschreibung des Features
#'   * Chromosome: Chromosom, auf welchem das Feature lokalisiert ist
#'   * Cytoband: Lokalisation des Features im Karyogramm
#'   * LocusLink: ???
#'   * Functions: ???
#' @md
rebuildData <- function(){
  gene_annot <- array_annotation
  blank_spots <- gene_annot %>%
    filter(acc == "" & UniGene == "" & Symbol == "" & Description == "") %>%
    select(ID)
  blank_spots <- blank_spots$ID

  data_raw <- array_data
  colnames(data_raw)[7] <- "CLL6"
  data_raw[,"RowNames"] <- factor(data_raw[,"RowNames"])
  data_blankless <- data_raw %>% filter(!(RowNames %in% blank_spots))
  data_transp <- t(data_blankless[,!(names(data_blankless) == "RowNames")])

  data_melted <- melt(data = data_blankless, id.vars = "RowNames")
  colnames(data_melted) <- c("Spot", "Patient", "Intensity")
  data_melted$group <- grepl("CLL", data_melted$Patient, fixed = TRUE) %>%
                       if_else("CLL", "NBC")

  built_data <- list(data_transp, data_melted, data_blankless, gene_annot)
  names(built_data) <- c("data_transp", "data_melted", "data_blankless", "gene_annot")
  return(built_data)
}

#' Erstellt ein hierarchisches Clustering in Form eines Dendrogramms
#'
#' Auf Basis der uebergebenen Parameter wird die Distanzmatrix berechnet (mit \link{dist}).
#' Mit der Distanzmatrix und den uebergebenen Parametern wird anschliessend das Clustering Objekt erstellt (mit \link{hclust}).
#' Das "hclust" Objekt wird in ein "dendrogram" Objekt konvertiert, gefaerbt mit \link{dendextend}
#' und als \link{ggplot2} Objekt gespeichert.
#'
#' @param data Ein Objekt, welches mit \link{rebuildData} erzeugt wurde.
#' @param dist_measure Distanzmass, das fuer die Berechnung der Distanzmatrix verwendet werden soll. Eines von
#' \code{c("Euklidisch", "Manhattan", "Minkowski", "Tschebyschew", "Canberra")}
#' @param clust_method Clustering-Algorithmus, der fuer die Generierung des Dendrogramms verwendet werden soll. Eines von
#' \code{c("Single-Linkage", "Complete-Linkage", "Average-Linkage (UPGMA)", "Centroid-Linkage (UPGMC)", "Median-Linkage (WPGMC)", "WPGMA")}
#' @param color_choice logischer Wert. Gibt an, ob das Dendrogramm eingefaerbt werden soll.
#' @param k Wenn \code{color_choice = TRUE}: Integer-Wert. Gibt an, in wieviele Cluster das Dendrogramm farblich aufgeteilt werden soll.
#' @param p Wenn \code{dist_measure = "Minkowski"}: Integer-Wert. Gibt den Exponenten \code{p} der p-Norm an.
#'
#' @return Ein Objekt vom Typ \code{ggplot}, siehe \link[ggplot2]{ggplot}. Visuelle Repraesentation des hierarchischen Clusterings.
perform_Clustering <- function(data, dist_measure, clust_method, color_choice, k, p){
  switch(dist_measure,
         "Euklidisch" = {
            dist_measure <- "euclidean"
         },
         "Manhattan" = {
            dist_measure <- "manhattan"
         },
         "Minkowski" = {
            dist_measure <- "minkowski"
         },
         "Tschebyschew" = {
           dist_measure <- "maximum"
         },
         "Canberra" = {
           dist_measure <- "canberra"
         }
  )

  switch(clust_method,
         "Single-Linkage" = {
           clust_method <- "single"
         },
         "Complete-Linkage" = {
           clust_method <- "complete"
         },
         "Average-Linkage (UPGMA)" = {
           clust_method <- "average"
         },
         "Centroid-Linkage (UPGMC)" = {
           clust_method <- "centroid"
         },
         "Median-Linkage (WPGMC)" = {
           clust_method <- "median"
         },
         "WPGMA" = {
           clust_method <- "mcquitty"
         }
         )
  if(dist_measure == "minkowski"){
    distance_matrix <- dist(data$data_transp, method = "minkowski", p = p)
  }
  else{
    distance_matrix <- dist(data$data_transp, method = dist_measure)
  }
  cluster_hclust <- hclust(distance_matrix, method = clust_method)
  cluster_dendro <- as.dendrogram(cluster_hclust)
  if(color_choice){
    cluster_dendro <- cluster_dendro %>%
                      set("branches_k_color", k = k) %>%
                      set("labels_color", k = k) %>%
                      set("hang")
  }
  else{
    cluster_dendro <- cluster_dendro %>%
                      set("hang")
  }
  ggdendro <- as.ggdend(cluster_dendro)
  ggdendro_plot <- ggplot(ggdendro) +
                    theme_minimal() +
                    theme(text = element_text(size=20),
                          axis.text.x = element_blank(),
                          axis.ticks.x = element_blank()) +
                    labs(x = "Patient",
                         y = "Distance")
  return(ggdendro_plot)
}

#' Erstellt Boxplots der Intensitaetsverteilungen
#'
#' Generiert Boxplots der Array-Intensitaetsverteilungen fuer jeden Patienten / jedes Sample.
#' Die Farbe des Plots symbolisiert dabei die Zugehoerigkeit zur jeweiligen Patientengruppe ("CLL" / "NBC")
#'
#' @param data Ein Objekt, welches mit \link{rebuildData} erzeugt wurde.
#'
#' @return Ein Objekt vom Typ \code{ggplot}, siehe \link[ggplot2]{ggplot}.
plot_Boxplots <- function(data){
  ggBoxplots <- ggplot(data = data$data_melted, aes(x = Patient, y = Intensity, fill = group)) +
                geom_boxplot() +
                theme_bw() +
                theme(text = element_text(size=20),
                      legend.position="bottom")
  return(ggBoxplots)
}

#' Stellt tabellarisch Aehnlichkeiten zwischen Features/Genen der Patientengruppen dar.
#'
#' Fuer alle Gene/Features auf dem Array wird ein statistischer Test durchgefuehrt
#' (Wilcoxon Rank-Sum Test) (mit \link{wilcox.test}).
#' Dabei werden jeweils die Samples der Gruppe "CLL" gegen die Samples der Gruppe "NBC" getestet.
#' Die Spots werden nach dem vom Test berechneten p-Value aufsteigend sortiert,
#' alle Spots mit einem p-Value > 0.05 (Konfidenzniveau = 95%) werden entfernt.
#' Die verbleibenden Spots werden mit der der Spotnummer zugehoerigen Array-Annotation zu einem
#' Data Frame verschmolzen.
#'
#' @param data Ein Objekt, welches mit \link{rebuildData} erzeugt wurde.
#'
#' @return Ein Objekt vom Typ \code{data.frame} mit 2567 Zeilen und 5 Spalten:
#' * Spot: Laufende Spot-Nummer
#' * acc: GenBank Accession Number
#' * Symbol: GeneSymbol
#' * Description: Beschreibung des Features
#' * p_Value: p-Value des Wilcoxon Rank-Sum Tests
#' @md
draw_Table <- function(data){
  stats_wilcox_test <- data.frame("Spot" = data$data_blankless$RowNames,
                                  "p_value" = apply(data$data_blankless,
                                                    1,
                                                    function(x) wilcox.test(x = as.numeric(x[2:7]),
                                                                            y = as.numeric(x[8:13]),
                                                                            exact = FALSE)$p.value))
  stats_genes <- merge(stats_wilcox_test, data$gene_annot, by.x = "Spot", by.y = "ID") %>%
    select("Spot", "acc", "Symbol", "Description", "p_value") %>%
    filter(!!as.name("p_value") < 0.05) %>%
    arrange(!!as.name("p_value"))
  return(stats_genes)
}
