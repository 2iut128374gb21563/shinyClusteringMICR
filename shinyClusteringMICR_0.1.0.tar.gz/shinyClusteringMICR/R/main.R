#library(ggplot2)
#library(reshape2)
#library(dplyr)
#library(dendextend)


rebuildData <- function(){
  gene_annot <- read.csv(file = system.file("extdata", "rgdAnnot.txt", package = "shinyClusteringMICR"),
                         header = TRUE,
                         sep = "\t")
  blank_spots <- gene_annot %>%
    filter("acc" == "" & "UniGene" == "" & "Symbol" == "" & "Description" == "") %>%
    select("ID")
  blank_spots <- blank_spots$"ID"

  data_raw <- read.csv(file = system.file("extdata", "cllnormalized.txt", package = "shinyClusteringMICR"),
                       header = TRUE,
                       sep = "\t")
  colnames(data_raw)[7] <- "CLL6"
  data_raw[,"RowNames"] <- factor(data_raw[,"RowNames"])
  data_blankless <- data_raw %>% filter(!("RowNames" %in% blank_spots))
  data_transp <- t(data_blankless[,!(names(data_blankless) == "RowNames")])

  data_melted <- melt(data = data_blankless, id.vars = "RowNames")
  colnames(data_melted) <- c("Spot", "Patient", "Intensity")
  data_melted$group <- grepl("CLL", data_melted$Patient, fixed = TRUE) %>%
                       if_else("CLL", "NBC")

  built_data <- list(data_transp, data_melted, data_blankless, gene_annot)
  names(built_data) <- c("data_transp", "data_melted", "data_blankless", "gene_annot")
  return(built_data)
}

perform_Clustering <- function(data, dist_measure, clust_method, color_choice, k, p){
  switch(dist_measure,
         "Euklidisch" = {
            dist_measure <- "euclidean"
         },
         "Manhattan" = {
            dist_measure <- "manhattan"
         },
         "Minkowski" = {
            dist_measure <- "minkowski"
         },
         "Tschebyschew" = {
           dist_measure <- "maximum"
         },
         "Canberra" = {
           dist_measure <- "canberra"
         }
  )

  switch(clust_method,
         "Single-Linkage" = {
           clust_method <- "single"
         },
         "Complete-Linkage" = {
           clust_method <- "complete"
         },
         "Average-Linkage (UPGMA)" = {
           clust_method <- "average"
         },
         "Centroid-Linkage (UPGMC)" = {
           clust_method <- "centroid"
         },
         "Median-Linkage (WPGMC)" = {
           clust_method <- "median"
         },
         "WPGMA" = {
           clust_method <- "mcquitty"
         }
         )
  if(dist_measure == "minkowski"){
    distance_matrix <- dist(data$data_transp, method = "minkowski", p = p)
  }
  else{
    distance_matrix <- dist(data$data_transp, method = dist_measure)
  }
  cluster_hclust <- hclust(distance_matrix, method = clust_method)
  cluster_dendro <- as.dendrogram(cluster_hclust)
  if(color_choice){
    cluster_dendro <- cluster_dendro %>%
                      set("branches_k_color", k = k) %>%
                      set("labels_color", k = k) %>%
                      set("hang")
  }
  else{
    cluster_dendro <- cluster_dendro %>%
                      set("hang")
  }
  ggdendro <- as.ggdend(cluster_dendro)
  ggdendro_plot <- ggplot(ggdendro) +
                    theme_minimal() +
                    theme(text = element_text(size=20),
                          axis.text.x = element_blank(),
                          axis.ticks.x = element_blank()) +
                    labs(x = "Patient",
                         y = "Distance")
  return(ggdendro_plot)
}

plot_Boxplots <- function(data){
  ggBoxplots <- ggplot(data = data$data_melted, aes(x = Patient, y = Intensity, fill = group)) +
                geom_boxplot() +
                theme_bw() +
                theme(text = element_text(size=20),
                      legend.position="bottom")
  return(ggBoxplots)
}

draw_Table <- function(data){
  stats_wilcox_test <- data.frame("Spot" = data$data_blankless$RowNames,
                                  "p_value" = apply(data$data_blankless,
                                                    1,
                                                    function(x) wilcox.test(x = as.numeric(x[2:7]),
                                                                            y = as.numeric(x[8:13]),
                                                                            exact = FALSE)$p.value))
  stats_genes <- merge(stats_wilcox_test, data$gene_annot, by.x = "Spot", by.y = "ID") %>%
    select("Spot", "acc", "Symbol", "Description", "p_value") %>%
    filter(!!as.name("p_value") < 0.05) %>%
    arrange(!!as.name("p_value"))
  return(stats_genes)
}
