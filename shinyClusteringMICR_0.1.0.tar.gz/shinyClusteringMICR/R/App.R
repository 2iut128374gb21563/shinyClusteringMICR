shiny_package_ui <- function(){
  fluidPage(title = "Hierarchisches Clustering von Microarray Daten",
            titlePanel("Hierarchisches Clustering von Microarray Daten"),
              sidebarLayout(
                sidebarPanel(
                  width = 3,
                  helpText("Diese App dient einer simplen Cluster-Analyse von Microarraydaten. Weitere Analysen sind unter \"Zusaetzliche Outputs\" verfuegbar."),
                  br(),

                  selectInput(inputId = "distance_measure",
                              label = "Distanzmass fuer die Berechnung der Distanzmatrix",
                              choices = c("Euklidisch", "Manhattan", "Minkowski", "Tschebyschew", "Canberra"),
                              selected = "Euklidisch"),

                  conditionalPanel(
                    condition = "input.distance_measure == 'Minkowski'",
                    sliderInput(inputId = "minkowski_p",
                                label = "Wert des Parameters p der p-Norm (Minkowski-Distanz)",
                                min = 2,
                                max = 20,
                                value = 2,
                                step = 1,
                                pre = "p = ")),

                  selectInput(inputId = "clustering_method",
                              label = "Zu verwendende Clustering-Methode",
                              choices = c("Single-Linkage", "Complete-Linkage", "Average-Linkage (UPGMA)", "Centroid-Linkage (UPGMC)", "WPGMA", "Median-Linkage (WPGMC)"),
                              selected = "Average-Linkage (UPGMA)"),

                  checkboxInput(inputId = "color_clusters_choice",
                                label = "Dendrogramm in k Cluster aufteilen?",
                                value = TRUE),

                  conditionalPanel(
                    condition = "input.color_clusters_choice == true",
                    sliderInput(inputId = "color_clusters_k",
                                label = "Teile das Dendrogramm in k Cluster auf",
                                min = 1,
                                max = 20,
                                value = 3,
                                step = 1,
                                pre = "k = ")),

                  selectInput(inputId = "secondary_output_choice",
                              label = "Zusaetzliche Outputs",
                              choices = c("Nichts", "Differentiell exprimierte Gene zwischen CLL und NBC Patienten", "Boxplots der Intensitaetsverteilungen aller Patienten"),
                              selected = "Boxplots der Intensitaetsverteilungen aller Patienten"),

                  p("CLL = Chronic lymphocytic leukemia (Chronische lymphatische Leukaemie)"),
                  p("NBC = Normal B-Cells"),
                  p("Quelle der verwendeten Daten:", br(),
                    p("J. Wang, K. R. Coombes, W. E. Highsmith, M. J. Keating, L. V. Abruzzo, Differences in gene expression between B-cell chronic lymphocytic leukemia and normal B cells: a meta-analysis of three microarray studies, Bioinformatics, Volume 20, Issue 17, 22 November 2004, Pages 3166-3178"),
                    a(href = "https://doi.org/10.1093/bioinformatics/bth381", "https://doi.org/10.1093/bioinformatics/bth381")),
                ),

                mainPanel(
                  conditionalPanel(condition="$('html').hasClass('shiny-busy')",
                                   tags$div(strong("Berechne, Bitte warten..."),id="loadmessage")),

                  h3("Cluster Dendrogramm"),
                  plotOutput(outputId = "clustering_dendrogram",
                             height = "800px"),

                  br(),
                  conditionalPanel(
                    condition = "input.secondary_output_choice == 'Differentiell exprimierte Gene zwischen CLL und NBC Patienten'",
                    h3("Differentiell exprimierte Gene zwischen CLL und NBC Patienten"),
                    p("Die folgende Tabelle zeigt alle Gene (nicht-leere Spots auf dem Microarray) mit einem vom Wilcoxon-Rank-Sum-Test berechneten p-Value < 0.05 in aufsteigender Reihenfolge.
                      Fuer jedes Gen werden dabei die Samples der beiden Gruppen CLL und NBC gegeneinander getestet."),
                    p("Beschreibung der Spaltennamen:"),
                    p("Spot = Laufende Spotnummer auf dem Microarray"),
                    p("acc = GenBank Accession Number"),
                    p("Symbol = (UniProt) Gene Symbol"),
                    p("Description = Beschreibung/Bedeutung des Features"),
                    p("p_value = Wilcoxon-Rank-Sum-Test p_value zwischen CLL und NBC Patienten"),

                    tableOutput(outputId = "wilcox_tests")
                  ),

                  conditionalPanel(
                    condition = "input.secondary_output_choice == 'Boxplots der Intensitaetsverteilungen aller Patienten'",
                    h3("Boxplots der Intensitaetsverteilungen aller Patienten"),
                    plotOutput(outputId = "boxplots")
                  )
                )
              )
            )
}

shiny_package_server <- function(input, output){

  data <- reactive({rebuildData()})

  output$clustering_dendrogram <- renderPlot({
    perform_Clustering(data = data(),
                       input$distance_measure,
                       input$clustering_method,
                       input$color_clusters_choice,
                       input$color_clusters_k,
                       input$minkowski_p)
  })
  output$boxplots <- renderPlot({
    plot_Boxplots(data = data())
  })
  output$wilcox_tests <- renderTable({
    draw_Table(data = data())
  },
  hover = TRUE,
  striped = FALSE,
  bordered = TRUE,
  width = "auto",
  rownames = TRUE,
  digits = -4)
}

#' Add together two numbers.
#'
#' @return bla
#' @examples
#'
#' @export
#'
runShinyClusteringMICR <- function(){
  app <- shiny::shinyApp(ui = shiny_package_ui(), server = shiny_package_server)
  shiny::runApp(app, launch.browser = TRUE)
}

