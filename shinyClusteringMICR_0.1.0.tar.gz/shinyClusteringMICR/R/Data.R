#' DATA: Microarray Spot Annotation
#'
#' Dieses Datenset beinhaltet die binaere Form der unverarbeiteten Array-Annotation.
#' Der Code fuer die Generierung befindet sich im Verzeichnis \code{"/data-raw/"}.
#' Die Rohdaten befinden sich im Verzeichnis \code{"/inst/extdata/"}.
#'
#' @format Ein Objekt vom Typ \code{data.frame} mit 34560 Zeilen und 9 Spalten
#' \describe{
#'   \item{ID}{Laufende Spotnummer}
#'   \item{acc}{GenBank accession number}
#'   \item{UniGene}{UniGene accession number}
#'   \item{Symbol}{GeneSymbol}
#'   \item{Description}{Beschreibung des Features}
#'   \item{Chromosome}{Chromosom, auf welchem das Feature lokalisiert ist}
#'   \item{Cytoband}{Lokalisation des Features im Karyogramm}
#'   \item{LocusLink}{Unbekannt}
#'   \item{Functions}{Unbekannt}
#' }
#' @source \url{https://doi.org/10.1093/bioinformatics/bth381}
"array_annotation"

#' DATA: (Normalisierte) Microarray Daten
#'
#' Dieses Datenset beinhaltet die binaere Form der unverarbeiteten normalisierten Microarray-Daten.
#' Der Code fuer die Generierung befindet sich im Verzeichnis \code{"/data-raw"}.
#' Die Rohdaten befinden sich im Verzeichnis \code{"/inst/extdata"}.
#'
#' @format Ein Objekt vom Typ \code{data.frame} mit 34560 Zeilen und 13 Spalten
#' \describe{
#'   \item{RowNames}{Laufende Spotnummer entsprechend der Variable \code{ID} der Array-Annotation}
#'   \item{CLL1}{CLL-Patient 1}
#'   \item{CLL2}{CLL-Patient 2}
#'   \item{CLL3}{CLL-Patient 3}
#'   \item{CLL4}{CLL-Patient 4}
#'   \item{CLL5}{CLL-Patient 5}
#'   \item{CLL7}{CLL-Patient 6}
#'   \item{NBC1}{NBC-Patient 1}
#'   \item{NBC2}{NBC-Patient 2}
#'   \item{NBC3}{NBC-Patient 3}
#'   \item{NBC4}{NBC-Patient 4}
#'   \item{NBC5}{NBC-Patient 5}
#'   \item{NBC6}{NBC-Patient 6}
#' }
#' @source \url{https://doi.org/10.1093/bioinformatics/bth381}
"array_data"
