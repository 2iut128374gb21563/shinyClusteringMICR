#' Interaktives Hierarchisches Clustering von Microarraydaten
#'
#' The foo package provides three categories of important functions:
#' foo, bar and baz.
#'
#' @section Foo functions:
#' The foo functions ...
#'
#' @docType package
#' @name shinyClusteringMICR
#'
#' @import dplyr
#' @import ggplot2
#' @import reshape2
#' @import dendextend
#' @import shiny
#' @importFrom stats as.dendrogram dist hclust wilcox.test
#' @importFrom utils read.csv
NULL
