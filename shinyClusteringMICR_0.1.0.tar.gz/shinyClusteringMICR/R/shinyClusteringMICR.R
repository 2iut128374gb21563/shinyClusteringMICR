#' Interaktives Hierarchisches Clustering von Microarraydaten
#'
#' Das Package stellt Funktionen zur Erstellung eines hierarchischen Clusterings, Visualisierung von Intensitaetsverteilungen
#' und Durchfuehrung von statistischen Tests fuer Microarray-Daten zur Verfuegung.
#'
#' @section Einfuehrung:
#' Basierend auf den Daten eines Microarrayexperimentes sollen Aehnlichkeiten bzw. Unterschiede
#' in der Genexpression von ausgewaehlten Genen zwischen zwei Gruppen von Patienten und zwischen allen
#' Patienten untereinander gefunden und visualisiert werden.
#' Genauer gesagt geht es um Patienten mit der Krankheit "chronic lymphocytic leukemia (CLL)"
#' (="Chronische lymphatische Leukaemie") und jene ohne diese Erkrankung.
#' Bei der Erkrankung kommt es zu einer klonalen Vermehrung von reifen, kleinzelligen, aber funktionslosen B-Lymphozyten.
#' Daher wurden fuer das Experiment Proben von unbehandelten CLL-positiven B-Lymphozyten der CLL-Patienten entnommen und als Kontrolle
#' B-Lymphozyten-Proben von gesunden Patienten. Mit den Proben wurden anschliessend Microarray-Experimente auf verschiedenen
#' Plattformen durchgefuehrt, von denen hier nur eines naeher betrachtet wird.
#' Das Expressionslevel von circa 30000 Genen/Features wurde im Experiment gemessen, um so "Stichproben" des Transkriptoms
#' der Zellen zu erhalten.
#' Idealerweise moechte man durch die Experimente Gene zwsichen den Gruppen identifizieren, deren differentielle Expression
#' als ein effizienter Indikator fuer die Diagnose von CLL herangezogen werden kann.
#'
#' @section Eingabedaten:
#' Quelle und Format, siehe: \code{\link{array_data}, \link{array_annotation}}.
#' Die komplette Studie setzt sich aus Daten von 3 Plattformen zusammen: "Nylon membrane cDNA microarrays",
#' "Glass cDNA microarrays" und "Oligonucleotide arrays (Affymetrix)".
#' Die verwendeten Daten stammen von der Plattform mit "Nylon membrane cDNA microarrays".
#' 6 einzelne Arrays mit je 5184 Spots (fuer jeden Patienten) wurden in einem Datenset zusammengefasst
#' und die Messdaten/Intensitaeten nach Angaben des Autors normalisiert. So erhaelt man eine Matrix
#' mit Zeilen fuer alle Spots und Spalten fuer alle Patienten.
#' Es gibt jeweils 6 Samples von CLL-positiven (="CLL") - und 6 Samples von CLL-negativen (="NBC") Patienten.
#'
#' @section Verarbeitungsschritte:
#' Die unverarbeiteten, normalisierten Daten und die Array-Annotation liegen als tab-separierte .txt-Dateien
#' im Verzeichnis \code{"/inst/extdata/"} und wurden mit dem Code im Verzeichnis \code{"/data-raw/"} als binaeres Objekt gespeichert.
#' Die Binaerdaten werden von der Funktion \link{rebuildData} geladen, bearbeitet, transformiert und dem Shiny-Server-Teil
#' \link{shiny_package_server} als Objekt zur Verfuegung gestellt.
#' Der Benutzer waehlt dann ueber die Benutzeroberflaeche (generiert durch \link{shiny_package_ui}) die gewuenschten Parameter
#' fuer die Berechnung des Clusterings und die gewuenschten zusaetzlichen Ausgaben aus.
#' Die Funktion \link{perform_Clustering} generiert daraufhin das plot-Objekt des hierarchischen Clusterings,
#' \link{plot_Boxplots} erstellt das plot-Objekt der Boxplots und \link{draw_Table} fuehrt einen
#' statistischen Test durch und liefert eine Tabelle der Ergebnisse zurueck.
#' Der Benutzer kann die App ueber die Funktion \link{runShinyClusteringMICR} im Standardbrowser starten.
#'
#' @section Ausgabedaten:
#' Die Server-Funktion \link{shiny_package_server} rendert 3 Objekte in der Benutzeroberflaeche:
#' Das Cluster-Dendrogramm, Boxplots der Intensitaetsverteilungen der Samples/Patienten und eine Tabelle mit
#' moeglicherweise differentiell exprimierter Gene zwischen den Patientengruppen (basierend auf dem
#' Wilcoxon Rank-Sum Test unabhaengiger Variablen).
#'
#' @section Interpretation der Ergebnisse:
#' Bei Verwendung von "Euklidisch" als Distanzmass und "Average-Linkage" als Clustering-Methode lassen sich 3 Cluster identifizieren:
#' Cluster1: [CLL2], Cluster2: [CLL1, CLL3, CLL4, CLL5, CLL6], Cluster3: [NBC1, NBC2, NBC3, NBC4, NBC5, NBC6].
#' Bei Verwendung von k = 3 werden die Cluster in der Visualisierung entsprechend eingefaerbt.
#' Die Expressionsmuster der Proben der gesunden Patienten (NBC) weisen keine grossen Distanzen untereinander auf
#' und sind daher aehnlich zueinander. Zumindest im Hinblick auf die gemessene Expression der 30000+ Features auf dem Array scheinen
#' die Transkriptome der NBC Patienten eine hohe Aehnlichkeit zu haben.
#' Die Proben der CLL-Patienten weisen ein vergleichbares Distanzverhalten auf, mit Ausnahme der Probe "CLL2". Diese Probe weist eine so
#' hohe Distanz zu allen anderen Proben auf, dass sie keinem der beiden bereits existierenden Cluster zugeordnet werden kann.
#' Hier koennte es sich um einen systematischen Fehler im Experiment handeln oder die Probe weist tatsaechlich ein stark unterschiedliches
#' Expressionsverhalten bzgl. der gemessen 30000+ Features auf. Womoeglich leidet der Patient an einer weiteren Erscheinungsform von CLL
#' oder die B-Lymphozyten dieses Patienten weisen aus anderen Gruenden ein abnormales Transkriptom auf.
#' Im Hinblick auf die zwei Patientengruppen laesst sich anhand des Clusterings sagen, dass zwischen CLL- und nicht-CLL Patienten eine
#' so grosse Distanz besteht, dass man von einem deutlich unterschiedlichen Transkriptom ausgehen kann.
#' Beim Betrachten der Boxplots faellt auf, dass die Daten scheinbar nicht korrekt normalisiert worden sind.
#' Der Mittelwert und die Standardabweichung der Verteilungen sollten gleich sein; dies ist offensichtlich nicht der Fall.
#' Betrachtet man die Tabelle der Gene/Features, die nach dem Anwenden des statistischen Tests einen p-Value < 0.05 besitzen,
#' so stellt man fest, dass 2567 von den 32112 nicht-leeren Spots eine hinreichende statistische Signifikanz zeigen. Diese Features sollte man
#' genauer untersuchen; insbesondere Gene, die nachweislich in CLL eine Rolle spielen, um auf diese Weise einen Nachweis fuer die vorhandene
#' Krankheit in den Proben der CLL-Patienten zu bekraeftigen und die Abwesenheit der Krankheit in den Proben der gesunden Patienten zu belegen.
#'
#'
#' @seealso \code{\link{array_annotation}}, \code{\link{array_data}}, \code{\link{draw_Table}},
#' \code{\link{perform_Clustering}}, \code{\link{plot_Boxplots}}, \code{\link{rebuildData}},
#' \code{\link{runShinyClusteringMICR}}, \code{\link{shiny_package_server}}, \code{\link{shiny_package_ui}}
#'
#' @docType package
#' @name shinyClusteringMICR
#'
#' @import dplyr
#' @import ggplot2
#' @import reshape2
#' @import dendextend
#' @import shiny
#' @importFrom stats as.dendrogram dist hclust wilcox.test
#' @importFrom utils read.csv
NULL
